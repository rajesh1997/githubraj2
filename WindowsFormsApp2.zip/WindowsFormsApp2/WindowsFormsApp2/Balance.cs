﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Balance : Form
    {
        public Balance()
        {
            InitializeComponent();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void btn_balance_Click(object sender, EventArgs e)
        {
            SqlConnection c1 = new SqlConnection(@"Data Source = localhost;Initial Catalog = user_data;Integrated Security = True");
            c1.Open();
            SqlCommand cmd1 = new SqlCommand("sp_search", c1);
            cmd1.CommandType = CommandType.StoredProcedure;
            SqlParameter p1 = new SqlParameter("@searchdata", SqlDbType.VarChar);
            cmd1.Parameters.Add(p1).Value = cmb_name.Text.Trim();
            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_.DataSource = ds.Tables[0];
        }
    }
}
