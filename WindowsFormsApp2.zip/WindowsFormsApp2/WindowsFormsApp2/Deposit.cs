﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Deposit : Form
    {
        public Deposit()
        {
            InitializeComponent();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void cmb_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            
       
        }

        private void txt_balance_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Deposit_Load(object sender, EventArgs e)
        {
            string connect = ConfigurationManager.ConnectionStrings["Myconn"].ConnectionString;
            SqlConnection con = new SqlConnection(connect);
            string sqlquery = "select name,balance from create_user";
            SqlCommand sqlcomm = new SqlCommand(sqlquery, con);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(sqlcomm);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmb_name.DisplayMember = "name";
            cmb_balance.DisplayMember = "balance";
            cmb_name.DataSource = dt;
            cmb_balance.DataSource = dt;
            con.Close();
            

        }

        private void cmb_balance_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void txt_total_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txt_deposit_TextChanged(object sender, EventArgs e)
        {
            if (txt_deposit.Text.Length > 0)
            {
                txt_total.Text = (Convert.ToDecimal(cmb_balance.Text) + Convert.ToDecimal(txt_deposit.Text)).ToString();

            }
        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            SqlConnection c = new SqlConnection(@"Data Source = localhost;Initial Catalog = user_data;Integrated Security = True");
            c.Open();
            SqlCommand cmd = new SqlCommand("sp_deposit", c);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p1 = new SqlParameter("@name", SqlDbType.VarChar);
            cmd.Parameters.Add(p1).Value = cmb_name.Text.Trim();
            SqlParameter p2 = new SqlParameter("@balance", SqlDbType.Decimal);
            cmd.Parameters.Add(p2).Value = cmb_balance.Text.Trim();
            SqlParameter p3 = new SqlParameter("@deposit_amount", SqlDbType.Decimal);
            cmd.Parameters.Add(p3).Value = txt_deposit.Text.Trim();
            SqlParameter p4 = new SqlParameter("@total", SqlDbType.Decimal);
            cmd.Parameters.Add(p4).Value = txt_total.Text.Trim();

            int a = cmd.ExecuteNonQuery();

            if (a > 0)
            {
                MessageBox.Show("deposited Successful");
                SqlConnection c1 = new SqlConnection(@"Data Source = localhost;Initial Catalog = user_data;Integrated Security = True");
                c1.Open();
                SqlCommand cmd1 = new SqlCommand("deposit_fetch", c1);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter da = new SqlDataAdapter(cmd1);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dgv_.DataSource = ds.Tables[0];
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void txt_balance_TextChanged_1(object sender, EventArgs e)
        {
            
        }
    }
}
