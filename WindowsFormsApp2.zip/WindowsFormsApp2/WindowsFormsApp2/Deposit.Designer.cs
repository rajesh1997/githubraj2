﻿namespace WindowsFormsApp2
{
    partial class Deposit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.lbl_depositAmount = new System.Windows.Forms.Label();
            this.txt_deposit = new System.Windows.Forms.TextBox();
            this.cmb_name = new System.Windows.Forms.ComboBox();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.dgv_ = new System.Windows.Forms.DataGridView();
            this.btn_back = new System.Windows.Forms.Button();
            this.lbl_total = new System.Windows.Forms.Label();
            this.txt_total = new System.Windows.Forms.TextBox();
            this.cmb_balance = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.Location = new System.Drawing.Point(176, 60);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(58, 22);
            this.lbl_name.TabIndex = 0;
            this.lbl_name.Text = "Name";
            // 
            // lbl_balance
            // 
            this.lbl_balance.AutoSize = true;
            this.lbl_balance.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_balance.Location = new System.Drawing.Point(170, 107);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(76, 22);
            this.lbl_balance.TabIndex = 1;
            this.lbl_balance.Text = "Balance";
            // 
            // lbl_depositAmount
            // 
            this.lbl_depositAmount.AutoSize = true;
            this.lbl_depositAmount.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_depositAmount.Location = new System.Drawing.Point(128, 154);
            this.lbl_depositAmount.Name = "lbl_depositAmount";
            this.lbl_depositAmount.Size = new System.Drawing.Size(140, 22);
            this.lbl_depositAmount.TabIndex = 2;
            this.lbl_depositAmount.Text = "Deposit Amount";
            // 
            // txt_deposit
            // 
            this.txt_deposit.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_deposit.Location = new System.Drawing.Point(274, 154);
            this.txt_deposit.Name = "txt_deposit";
            this.txt_deposit.Size = new System.Drawing.Size(121, 25);
            this.txt_deposit.TabIndex = 5;
            this.txt_deposit.TextChanged += new System.EventHandler(this.txt_deposit_TextChanged);
            // 
            // cmb_name
            // 
            this.cmb_name.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_name.FormattingEnabled = true;
            this.cmb_name.Location = new System.Drawing.Point(274, 60);
            this.cmb_name.Name = "cmb_name";
            this.cmb_name.Size = new System.Drawing.Size(121, 25);
            this.cmb_name.TabIndex = 6;
            this.cmb_name.SelectedIndexChanged += new System.EventHandler(this.cmb_name_SelectedIndexChanged);
            // 
            // btn_deposit
            // 
            this.btn_deposit.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_deposit.Location = new System.Drawing.Point(270, 248);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(75, 29);
            this.btn_deposit.TabIndex = 7;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // dgv_
            // 
            this.dgv_.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_.Location = new System.Drawing.Point(132, 292);
            this.dgv_.Name = "dgv_";
            this.dgv_.Size = new System.Drawing.Size(529, 150);
            this.dgv_.TabIndex = 8;
            // 
            // btn_back
            // 
            this.btn_back.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.Location = new System.Drawing.Point(536, 31);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(75, 26);
            this.btn_back.TabIndex = 9;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_total.Location = new System.Drawing.Point(176, 212);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(52, 22);
            this.lbl_total.TabIndex = 10;
            this.lbl_total.Text = "Total";
            // 
            // txt_total
            // 
            this.txt_total.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total.Location = new System.Drawing.Point(274, 212);
            this.txt_total.Name = "txt_total";
            this.txt_total.Size = new System.Drawing.Size(121, 25);
            this.txt_total.TabIndex = 11;
            this.txt_total.TextChanged += new System.EventHandler(this.txt_total_TextChanged);
            // 
            // cmb_balance
            // 
            this.cmb_balance.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_balance.FormattingEnabled = true;
            this.cmb_balance.Location = new System.Drawing.Point(274, 107);
            this.cmb_balance.Name = "cmb_balance";
            this.cmb_balance.Size = new System.Drawing.Size(121, 25);
            this.cmb_balance.TabIndex = 12;
            // 
            // Deposit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(684, 466);
            this.Controls.Add(this.cmb_balance);
            this.Controls.Add(this.txt_total);
            this.Controls.Add(this.lbl_total);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.dgv_);
            this.Controls.Add(this.btn_deposit);
            this.Controls.Add(this.cmb_name);
            this.Controls.Add(this.txt_deposit);
            this.Controls.Add(this.lbl_depositAmount);
            this.Controls.Add(this.lbl_balance);
            this.Controls.Add(this.lbl_name);
            this.Name = "Deposit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Deposit";
            this.Load += new System.EventHandler(this.Deposit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.Label lbl_depositAmount;
        private System.Windows.Forms.TextBox txt_deposit;
        private System.Windows.Forms.ComboBox cmb_name;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.DataGridView dgv_;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.TextBox txt_total;
        private System.Windows.Forms.ComboBox cmb_balance;
    }
}