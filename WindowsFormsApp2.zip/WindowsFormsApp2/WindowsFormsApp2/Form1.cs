﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_create_Click(object sender, EventArgs e)
        {
            Create c = new Create();
            c.Show();
            this.Hide();
        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            Deposit d = new Deposit();
            d.Show();
            this.Hide();
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            Withdraw w = new Withdraw();
            w.Show();
            this.Hide();
        }

        private void btn_balance_Click(object sender, EventArgs e)
        {
            Balance b = new Balance();
            b.Show();
            this.Hide();
        }
    }
}
