﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Create : Form
    {
        public Create()
        {
            InitializeComponent();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void btn_create_Click(object sender, EventArgs e)
        {
            SqlConnection c = new SqlConnection(@"Data Source = localhost;Initial Catalog = user_data;Integrated Security = True");
            c.Open();
            SqlCommand cmd = new SqlCommand("store_create", c);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p1 = new SqlParameter("@name", SqlDbType.VarChar);
            cmd.Parameters.Add(p1).Value = txt_name.Text.Trim();
            SqlParameter p2 = new SqlParameter("@balance", SqlDbType.Decimal);
            cmd.Parameters.Add(p2).Value = txt_balance.Text.Trim();

            int a = cmd.ExecuteNonQuery();

            if(a > 0)
            {
                MessageBox.Show("Created Successful");
                SqlConnection c1 = new SqlConnection(@"Data Source = localhost;Initial Catalog = user_data;Integrated Security = True");
                c1.Open();
                SqlCommand cmd1 = new SqlCommand("create_fetch1", c1);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter da = new SqlDataAdapter(cmd1);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dgv_.DataSource = ds.Tables[0];
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            SqlConnection c = new SqlConnection(@"Data Source = localhost;Initial Catalog = user_data;Integrated Security = True");
            c.Open();
            SqlCommand cmd = new SqlCommand("sp_delete1", c);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p1 = new SqlParameter("@name", SqlDbType.VarChar);
            cmd.Parameters.Add(p1).Value = txt_name.Text.Trim();

            int a = cmd.ExecuteNonQuery();

            if(a > 0)
            {
                MessageBox.Show("deleted successful");
                SqlConnection c1 = new SqlConnection(@"Data Source = localhost;Initial Catalog = user_data;Integrated Security = True");
                c1.Open();
                SqlCommand cmd1 = new SqlCommand("create_fetch1", c1);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter da = new SqlDataAdapter(cmd1);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dgv_.DataSource = ds.Tables[0];
            }
            else
            {
                MessageBox.Show("Error");
            }

        }
    }
}
